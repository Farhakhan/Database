<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Swargate</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link type="text/css" href="css/styles.css" rel="stylesheet" media="all" />
</head>

<body>
<div id="wrapper">
	<div id="header">
    <h1><a href="index.php"></a></h1>
        <ul id="mainnav">
			<li><a href="index.php">Home</a></li>
            <li><a href="routes.php">Routes</a></li>
            <li class="current"><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
				<div id="contactleft">

				<table border="5px" >
				TYPE CONTACT HERE
				</table>	
				</div><br>
               	<div class="column-clear"></div>
			<div class="clearfix"></div>

    </div>
</div>
</body>
</html>
